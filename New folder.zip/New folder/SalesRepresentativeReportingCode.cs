﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for LowInventory
/// </summary>
public abstract class SalesRepresentativeReportingCode
{
    public SalesRepresentativeReportingCode()
    {

        _SalesRepID = 0;
        _SalesRepLastName = String.Empty;
        _SalesRepTypeID = 0;
        _SalesRepTypeName = String.Empty;
        _TerritoryName = String.Empty;
        _RegionName = String.Empty;
        _DistributionRegionName = String.Empty;
        _SubBusinessUnitName = String.Empty;
        _BusinessUnitName = String.Empty;
        _CompanyName = String.Empty;
        _SalesRepFirstName = String.Empty;
        _Title = String.Empty;
        _HireDate = DateTime.MinValue;
        _TerminationDate = DateTime.MinValue;
        _Notes = String.Empty;
        _VendorID = String.Empty;
        _SalesRepCompanyName = String.Empty;
        _DemoSigned = DateTime.MinValue;
        _TerritoryID = 0;
        _RegionID = 0;
        _DistributionRegionID = 0;
        _SubBusinessUnitID = 0;
        _SalesRepContactID = 0;
        _BusinessUnitID = 0;
        _CompanyID = 0;
        _EffectiveDate = DateTime.MinValue;
        _ExpirationDate = DateTime.MinValue;

    }

    private int _SalesRepID;
    private string _SalesRepLastName;
    private int _SalesRepTypeID;
    private string _SalesRepTypeName;
    public string _TerritoryName;
    public string _RegionName;
    public string _DistributionRegionName;
    public string _SubBusinessUnitName;
    public string _BusinessUnitName;
    private string _CompanyName;
    public string _SalesRepFirstName;
    public string _Title;
    private int _SalesRepContactID;
    private DateTime _HireDate;
    private DateTime _TerminationDate;
    public string _Notes;
    private string _VendorID;
    public string _SalesRepCompanyName;
    private DateTime _DemoSigned;
    private int _TerritoryID;
    private int _RegionID;
    private int _DistributionRegionID;
    private int _SubBusinessUnitID;
    private int _BusinessUnitID;
    private int _CompanyID;
    private DateTime _EffectiveDate;
    private DateTime _ExpirationDate;
    
    public int SalesRepID
    {
        get { return _SalesRepID; }
        set { _SalesRepID = value; }
    }

    public int SalesRepContactID
    {
        get { return _SalesRepContactID; }
        set { _SalesRepContactID = value; }
    }

    public string SalesRepLastName
    {
        get { return _SalesRepLastName; }
        set { _SalesRepLastName = value; }
    }

    public int SalesRepTypeID
    {
        get { return _SalesRepTypeID; }
        set { _SalesRepTypeID = value; }
    }

    public string SalesRepTypeName
    {
        get { return _SalesRepTypeName; }
        set { _SalesRepTypeName = value; }
    }

    public string TerritoryName
    {
        get { return _TerritoryName; }
        set { _TerritoryName = value; }
    }

    public string RegionName
    {
        get { return _RegionName; }
        set { _RegionName = value; }
    }

    public string DistributionRegionName
    {
        get { return _DistributionRegionName; }
        set { _DistributionRegionName = value; }
    }

    public string SubBusinessUnitName
    {
        get { return _SubBusinessUnitName; }
        set { _SubBusinessUnitName = value; }
    }

    public string BusinessUnitName
    {
        get { return _BusinessUnitName; }
        set { _BusinessUnitName = value; }
    }
    public string CompanyName
    {
        get { return _CompanyName; }
        set { _CompanyName = value; }
    }

    public string SalesRepFirstName
    {
        get { return _SalesRepFirstName; }
        set { _SalesRepFirstName = value; }
    }

    public string Title
    {
        get { return _Title; }
        set { _Title = value; }
    }
    public DateTime HireDate
    {
        get { return _HireDate; }
        set { _HireDate = value; }
    }
    public DateTime TerminationDate
    {
        get { return _TerminationDate; }
        set { _TerminationDate = value; }
    }
    public string Notes
    {
        get { return _Notes; }
        set { _Notes = value; }
    }

    public string VendorID
    {
        get { return _VendorID; }
        set { _VendorID = value; }
    }

    public string SalesRepCompanyName
    {
        get { return _SalesRepCompanyName; }
        set { _SalesRepCompanyName = value; }
    }

    public DateTime DemoSigned
    {
        get { return _DemoSigned; }
        set { _DemoSigned = value; }
    }


    public int TerritoryID
    {
        get { return _TerritoryID; }
        set { _TerritoryID = value; }
    }

    public int RegionID
    {
        get { return _RegionID; }
        set { _RegionID = value; }
    }

    public int DistributionRegionID
    {
        get { return _DistributionRegionID; }
        set { _DistributionRegionID = value; }
    }


    public int SubBusinessUnitID
    {
        get { return _SubBusinessUnitID; }
        set { _SubBusinessUnitID = value; }
    }


    public int BusinessUnitID
    {
        get { return _BusinessUnitID; }
        set { _BusinessUnitID = value; }
    }

    public int CompanyID
    {
        get { return _CompanyID; }
        set { _CompanyID = value; }
    }

    public DateTime EffectiveDate
    {
        get { return _EffectiveDate; }
        set { _EffectiveDate = value; }
    }

    public DateTime ExpirationDate
    {
        get { return _ExpirationDate; }
        set { _ExpirationDate = value; }
    }

    

    public DataSet GetSKPickingBoard2(string salesRepLastName,string salesRepTypeName ,string territoryName, string regionName,  string subBusinessUnitName, string businessUnitName, string companyName)// string distributionRegionName,
    {
        DataSet ds = new DataSet();

        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
            try
            {
                using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_GetSalesRepresentativeRecords", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (salesRepLastName == "Select One" || String.IsNullOrEmpty(salesRepLastName))
                    {
                        cmd.Parameters.AddWithValue("SalesRepLastName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SalesRepLastName", salesRepLastName);
                    }

                    if (salesRepTypeName == "Select One" || String.IsNullOrEmpty(salesRepTypeName))
                    {
                        cmd.Parameters.AddWithValue("SalesRepTypeName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SalesRepTypeName", salesRepTypeName);
                    }

                    if (territoryName == "Select One" || String.IsNullOrEmpty(territoryName))
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("TerritoryName", territoryName);
                    }

                    //if (distributionRegionName == "Select One" || String.IsNullOrEmpty(distributionRegionName))
                    //{
                    //    cmd.Parameters.AddWithValue("DistributionRegionName", DBNull.Value);
                    //}
                    //else
                    //{
                    //    cmd.Parameters.AddWithValue("DistributionRegionName", distributionRegionName);
                    //}

                    if (regionName == "Select One" || String.IsNullOrEmpty(regionName))
                    {
                        cmd.Parameters.AddWithValue("RegionName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("RegionName", regionName);
                    }

                    if (subBusinessUnitName == "Select One" || String.IsNullOrEmpty(subBusinessUnitName))
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("SubBusinessUnitName", subBusinessUnitName);
                    }

                    if (businessUnitName == "Select One" || String.IsNullOrEmpty(businessUnitName))
                    {
                        cmd.Parameters.AddWithValue("BusinessUnitName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("BusinessUnitName", businessUnitName);
                    }

                    if (companyName == "Select One" || String.IsNullOrEmpty(companyName))
                    {
                        cmd.Parameters.AddWithValue("CompanyName", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("CompanyName", companyName);
                    }

                    connection.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        return ds;
    }


    //public DataSet UpdateSKPickingBoard(CompanyReportingChild li, int memberships)
    //{
    //    DataSet ds = new DataSet();
    //    SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString());
    //    SqlCommand sqlCmd = new SqlCommand("dbo.Web_SR_UpdateCompanys", sqlConn);
    //    sqlCmd.CommandType = CommandType.StoredProcedure;

    //    //   if (memberships == 1 || memberships == 2)
    //    //   {

    //    sqlCmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = li.CompanyID;
    //    sqlCmd.Parameters.Add("@EffectiveDate", SqlDbType.DateTime).Value = li.EffectiveDate;
    //    sqlCmd.Parameters.Add("@ExpirationDate", SqlDbType.DateTime).Value = li.ExpirationDate;
    //    sqlCmd.Parameters.Add("@CompanyKey", SqlDbType.NVarChar).Value = li.CompanyKey;
    //    sqlCmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = li.CompanyName;
    //    sqlCmd.Parameters.Add("@CompanyLocalCurrency", SqlDbType.NVarChar).Value = li.CompanyLocalCurrency;
    //    sqlCmd.Parameters.Add("@SubSegmentName", SqlDbType.NVarChar).Value = li.SubSegmentName;

    //    //if (li.SegmentName == string.Empty)
    //    //{
    //    //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = DBNull.Value;
    //    //}
    //    //else
    //    //{
    //    //    sqlCmd.Parameters.Add("@SegmentName", SqlDbType.VarChar).Value = li.SegmentName;
    //    //}
    //    if (String.IsNullOrEmpty(HttpContext.Current.User.Identity.Name))
    //    {
    //        sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = "sysadmin";
    //    }
    //    else
    //    {
    //        sqlCmd.Parameters.Add("@UpdateUser", SqlDbType.VarChar).Value = HttpContext.Current.User.Identity.Name;
    //    }
    //    //  }

    //    try
    //    {
    //        sqlConn.Open();
    //        using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd))
    //        {
    //            adapter.Fill(ds);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return ds;
    //}
    
   
    //public DataSet AddNewCompany(string companyKey, string companyName, string companyLocalCurrency, string subSegmentName, string effectiveDate)//string date, string period, string quantity, string amountLCY, string amountSpotUSD, string amountAverageUSD, string costLCY, string costSpotUSD, string costAverageUSD, string comment, string adjustmentType, string countryName, string subBusinessUnitName, string companyName, string subSegmentName, string accountSubTypeName, string subCategoryName, string currencyName)
    //{
    //    DataSet ds = new DataSet();
    //    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString()))
    //        try
    //        {
    //            using (SqlCommand cmd = new SqlCommand("dbo.Web_SR_AddNewCompany", connection))
    //            {
    //                cmd.CommandType = CommandType.StoredProcedure;
    //                cmd.Parameters.AddWithValue("EffectiveDate", Convert.ToDateTime(effectiveDate));
    //                cmd.Parameters.AddWithValue("CompanyKey", companyKey);
    //                cmd.Parameters.AddWithValue("CompanyName", companyName);
    //                cmd.Parameters.AddWithValue("CompanyLocalCurrency", companyLocalCurrency);
    //                cmd.Parameters.AddWithValue("SubSegmentName", subSegmentName);


    //                connection.Open();
    //                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
    //                {
    //                    adapter.Fill(ds);
    //                }
    //            }            

    //        }
    //        catch (Exception ex)
    //        {
    //            throw ex;
    //        }
    //        finally
    //        {
    //            connection.Close();
    //        }
    //    return ds;
    //}


    }
