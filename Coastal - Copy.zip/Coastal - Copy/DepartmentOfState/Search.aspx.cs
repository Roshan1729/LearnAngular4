﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                location.DataSource = LocationNameList().Tables[0];
                location.DataTextField = "CityName";
                location.DataBind();
                location.Items.Insert(0, new ListItem("--Select--", "NA"));


                town.DataSource = TownNameList().Tables[0];
                town.DataTextField = "TownName";
                town.DataBind();
                town.Items.Insert(0, new ListItem("--Select--", "NA"));


                village.DataSource = VillageNameList().Tables[0];
                village.DataTextField = "VillageName";
                village.DataBind();
                village.Items.Insert(0, new ListItem("--Select--", "NA"));


                borough.DataSource = BoroughNameList().Tables[0];
                borough.DataTextField = "BoroughName";
                borough.DataBind();
                borough.Items.Insert(0, new ListItem("--Select--", "NA"));


                place.DataSource = PlaceNameList().Tables[0];
                place.DataTextField = "PlaceName";
                place.DataBind();
                place.Items.Insert(0, new ListItem("--Select--", "NA"));


                county.DataSource = CountyNameList().Tables[0];
                county.DataTextField = "CountyName";
                county.DataBind();
                county.Items.Insert(0, new ListItem("--Select--", "NA"));


                waterbody.DataSource = WaterBodyNameList().Tables[0];
                waterbody.DataTextField = "WaterBodyName";
                waterbody.DataBind();
                waterbody.Items.Insert(0, new ListItem("--Select--", "NA"));




            }

        }
        protected DataSet LocationNameList()
        {
            DataSet dsCity = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsCity);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsCity;
        }
        protected DataSet TownNameList()
        {
            DataSet dsTown = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsTown);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsTown;
        }
        protected DataSet VillageNameList()
        {
            DataSet dsVillage = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsVillage);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsVillage;
        }
        protected DataSet BoroughNameList()
        {
            DataSet dsBorough = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsBorough);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsBorough;
        }
        protected DataSet PlaceNameList()
        {
            DataSet dsPlace = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsPlace);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsPlace;
        }
        protected DataSet CountyNameList()
        {
            DataSet dsCounty = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsCounty);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsCounty;
        }
        protected DataSet WaterBodyNameList()
        {
            DataSet dsWater = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("sp_SearchFields", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        con.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dsWater);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsWater;
        }




        //protected void BtnSelect_Click(object sender, EventArgs e)
        //{
        //    lblSelectedValue.Text = waterbody.SelectedValue;

        //}
    }
}