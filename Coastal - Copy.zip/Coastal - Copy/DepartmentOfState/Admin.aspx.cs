﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace DemoLoginApplication
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnAddUserInfo(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("AddUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                     
                        cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = firstname.Value;
                        cmd.Parameters.Add("@Lastname", SqlDbType.VarChar).Value = lastname.Value;
                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value =login.Value;
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password.Value;
                        cmd.Parameters.Add("@RoleType", SqlDbType.VarChar).Value = roleType.SelectedItem.ToString();
                        cmd.Parameters.Add("@CreatedDate", SqlDbType.VarChar).Value = DateTime.Now;
                        cmd.Parameters.Add("@DeactivatedDate", SqlDbType.VarChar).Value = DateTime.Now.AddDays(365);
                        
                        con.Open();
                        cmd.ExecuteNonQuery();                        
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void DeleteUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("DeleteUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                                             
                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = UserName.Value;
                     
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void InactiveUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("InactivateUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = InactiveUserName.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void ActivateUser(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ActivateUser", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = ActivateUserName.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void ModifyUserRole(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ModifyUserRole", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = ModifyUserName.Value;
                        cmd.Parameters.Add("@NewRoleType", SqlDbType.NVarChar).Value = NewRole.SelectedItem.Value;

                       // cmd.Parameters.Add("@ExistingRole", SqlDbType.NVarChar).Value = ParameterDirection.Output;
                                              
                        con.Open();
                        cmd.ExecuteNonQuery();
                        //string abcd = cmd.Parameters.Add("@ExistingRole", SqlDbType.NVarChar).Value;
                        con.Close();

                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        protected void ResetPassword(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand("ResetPassword", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Login", SqlDbType.NVarChar).Value = UsrName.Value;
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = ResetUserPassword.Value;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
    }
}