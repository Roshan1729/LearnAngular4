﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoLoginApplication
{
    public partial class ContactInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
        }

        protected void Chkbox_CheckedChanged(object sender, EventArgs e)

        {
            if (Chkbox.Checked)
                Panel.Enabled = true;
            else
                Panel.Enabled = false;

            if (CheckBox1.Checked)
                Panel1.Enabled = true;
            else
                Panel1.Enabled = false;

            if (CheckBox2.Checked)
                Panel2.Enabled = true;
            else
                Panel2.Enabled = false;

            if (CheckBox3.Checked)
                Panel3.Enabled = true;
            else
                Panel3.Enabled = false;

            if (CheckBox4.Checked)
                Panel4.Enabled = true;
            else
                Panel4.Enabled = false;
        }

        //protected void DropDownList_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    if (list.SelectedValue != "--Select--" || DropDownList.SelectedValue != "--Select--")
        //    {

        //        Test.Enabled = true;

        //    }
        //    else
        //    {
        //        Test.Enabled = false;

        //    }
        //}
    }
}