﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoLoginApplication
{
    public partial class Map : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.User.Identity.IsAuthenticated)
            {
                FormsAuthentication.RedirectToLoginPage();
            }
        }
        //protected void Coastal_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("Coastal.html");

        //}
        //protected void LWRP_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("LWRP.html");

        //}
        //protected void SASS_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("SASS.html");

        //}
    }
}